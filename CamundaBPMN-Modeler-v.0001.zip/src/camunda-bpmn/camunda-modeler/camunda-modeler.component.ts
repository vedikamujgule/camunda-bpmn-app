import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import * as camundaModdlePackage from 'camunda-bpmn-moddle/resources/camunda.json';
import { InjectionNames, EntryFactory, BpmnModeler, PropertiesPanelModule, CamundaModdleDescriptor, ElementTemplates, CamundaPropertiesProvider, OriginalPaletteProvider, camundaModdleExtension } from "../../app/bpmn-js/bpmn-js";
declare var require: any;
const $: any = require('jquery');

@Component({
  selector: 'app-camunda-modeler',
  templateUrl: './camunda-modeler.component.html',
  styleUrls: ['./camunda-modeler.component.css']
})
export class CamundaModelerComponent implements OnInit {

  title = 'Camunda BPMN Modler';
  modeler;

  constructor(private http: HttpClient) {
  }

  ngOnInit(): void {
    this.load()
    this.modeler = new BpmnModeler({
      container: '#canvas',
      width: '100vw',
      height: '100vh',
      additionalModules: [
        { [InjectionNames.elementTemplates]: ['type', ElementTemplates.elementTemplates[1]] },
        { [InjectionNames.propertiesProvider]: ['type', CamundaPropertiesProvider.propertiesProvider[1]] },
        { [InjectionNames.originalPaletteProvider]: ['type', OriginalPaletteProvider] },
        camundaModdleExtension,
        PropertiesPanelModule,
        camundaModdlePackage,

      ],
      propertiesPanel: {
        parent: '#properties'
      },
      moddleExtensions: {
        camunda: CamundaModdleDescriptor
      },
      bpmnRenderer: {
        defaultFillColor: '#3336',
        defaultStrokeColor: '#000 '
      }
    });
  }

  handleError(err: any) {
    if (err) {
      console.warn('Ups, error: ', err);
    }
  }
  createNew() {
    const url = '../assets/bpmn/initial.bpmn';
    this.http.get(url, {
      headers: { observe: 'response' }, responseType: 'text'
    }).subscribe(
      async (x: any) => {
        console.log('Fetched XML, now importing: ', x);
        const result = await this.modeler.importXML(x);
        const { warnings } = result;
        console.log(warnings);
      },
      this.handleError
    );
  }


  //fucntion to load bpmn present in assets
  load() {
    const url = '../assets/bpmn/saveBuildingEntity.bpmn';
    this.http.get(url, {
      headers: { observe: 'response' }, responseType: 'text'
    }).subscribe(
      async (x: any) => {
        console.log('Fetched XML, now importing: ', x);
        const result = await this.modeler.importXML(x);
        const { warnings } = result;
        console.log(warnings);
      },
      this.handleError
    );
  }

  async saveBpmn() {
    try {
      var downloadLink = $('#js-download-diagram');
      const { xml } = await this.modeler.saveXML({ format: true });
      this.setEncoded(downloadLink, 'diagram.bpmn', xml);
    } catch (err) {

      console.error('Error happened saving XML: ', err);
      this.setEncoded(downloadLink, 'diagram.bpmn', null);
    }
  }

  // async saveSvg() {
  //   try {
  //     var downloadSvgLink = $('#js-download-svg');
  //   const { svg } = await this.modeler.saveSVG();
  //   this.setEncoded(downloadSvgLink, 'diagram.svg', svg);
  // } catch (err) {

  //   console.error('Error happened saving svg: ', err);
  //   this.setEncoded(downloadSvgLink, 'diagram.svg', null);
  // }
  // }

  setEncoded(link, name, data) {
    var encodedData = encodeURIComponent(data);
    if (data) {
      link.addClass('active').attr({
        'href': 'data:application/bpmn20-xml;charset=UTF-8,' + encodedData,
        'download': name
      });
    } else {
      link.removeClass('active');
    }
  }
}